package main

import (
	"log"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/joho/godotenv"
	"github.com/trezi-api/apis"
	"github.com/trezi-api/controllers"
	"github.com/trezi-api/middleware"
)

func main() {
	err := godotenv.Load()
	if err != nil {
		log.Fatal("Error loading .env file")
	}

	log.Println(apis.Endpoints.CustomerAPI)

	app := fiber.New()
	app.Use(logger.New())
	app.Use(cors.New(cors.Config{
		AllowMethods: "GET,POST",
	}))
	app.Use(middleware.Auth)

	app.Post("/push/customer", controllers.PostHttp)
	// app.Get("/health-check", func(c *fiber.Ctx) error {
	// 	return c.Status(200).JSON(&fiber.Map{
	// 		"response": "All Ok",
	// 	})
	// })

	log.Fatal(app.Listen(":7778"))
}
