package middleware

import (
	"fmt"
	"os"

	"github.com/gofiber/fiber/v2"
)

func Auth(c *fiber.Ctx) error {
	authHeader := c.Get("Authorization")
	if authHeader[7:] == os.Getenv("APP_PASSWORD") && authHeader[:7] == "Bearer " {
		token := authHeader[7:]
		fmt.Println("Bearer Token:", token)
		return c.Next()
	}
	return c.Status(500).JSON(&fiber.Map{
		"mess": "something went wrong",
	})
}
