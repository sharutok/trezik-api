package controllers

import (
	"encoding/json"
	"fmt"

	"github.com/gofiber/fiber/v2"
)


func PostHttp(c *fiber.Ctx) error{

	payload := map[string]string{}{
		"email":       "",
		"password":    "",
		"prefix":      "",
		"remember_me": false,
		"mode":        "",
	}

	payloadBytes, err := json.Marshal(payload)
	if err != nil {
		fmt.Printf("Error encoding payload: %v\n", err)
		return
	}
	app := fiber.New()
	client := app.Client()

	req := client.Post("http://localhost:8000/user-manage/login/check").
		Body(bytes.NewReader(payloadBytes)).
		Set("Content-Type", "application/json") // Set JSON Content-Type

	// Send the request and get the response
	resp, err := req.Response()
	if err != nil {
		fmt.Printf("Error sending request: %v\n", err)
		return
	}
	defer resp.Body.Close()

	// Print the response
	fmt.Printf("Status: %v\n", resp.StatusCode)
	body := new(bytes.Buffer)
	body.ReadFrom(resp.Body)
	fmt.Printf("Response: %v\n", body.String())

}
