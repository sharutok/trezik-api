package oraclequeries

func CustomerQuery() string {
	q := `SELECT 
	CUST_ACCOUNT_ID,
   ACCOUNT_NUMBER,
   REFERENCE_ACCOUNT ALAI_Customer_No_c,
   PARTY_NAME,
   ATTRIBUTE1 TYPE,
   CURRENCY_CODE,
   PRIMARY_PHONE_NUMBER,
   SECONDARY_PHONE_NUMBER,
   EMAIL_ADDRESS,
   ADDRESS1,
   CITY,
   STATE,
   POSTAL_CODE,
   STATUS,
   COUNTRY
   FROM AWL_COPS.COPS_CUSTOMER_ACCOUNTS
   WHERE currency_code = 'USD'`

	return q

}
