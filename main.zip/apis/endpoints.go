package apis

type ApiEndpoints struct {
	CustomerAPI string
}

var Endpoints = ApiEndpoints{
	CustomerAPI: "https://openapi.trezix.io/api/v1/storeCustomer",
}
